
#ifndef LEGUP_WRAP_H
#define LEGUP_WRAP_H
#include "legup/types.h"


extern int  aes_main_LEGUP_WRAP();
#endif
